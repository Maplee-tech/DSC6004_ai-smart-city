"""4号 分类任务（Hot33）：三种策略对比

M1 city-global          : 一个逻辑回归，所有站混训，不带站点身份
M2 station-specific     : 每站一个逻辑回归（单类别站无法拟合，记 NA）
M3 pooled station-aware : 一个逻辑回归，station_id 作为类别特征

流程：2024 训练 → 2025 验证集选 C / class_weight 和决策阈值 → 冻结后评估 2025/2026。
2026 只用于最终评估，不参与任何选择。

运行：
    python train_classification.py
    python train_classification.py --c-grid 0.01,0.1,1,10
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from common import (
    DATA_PKG,
    OUTPUT_DIR,
    best_f1_threshold,
    calibration_bins,
    classification_metrics,
    load_manifest,
    load_split,
    make_preprocessor,
)

STRATEGIES = {
    "M1": {"label": "city_global", "station_aware": False, "station_specific": False},
    "M2": {"label": "station_specific", "station_aware": False, "station_specific": True},
    "M3": {"label": "pooled_station_aware", "station_aware": True, "station_specific": False},
}


def make_model(features: list[str], c_value: float, class_weight, station_aware: bool) -> Pipeline:
    return Pipeline(
        [
            ("preprocess", make_preprocessor(features, station_aware=station_aware)),
            (
                "model",
                LogisticRegression(
                    C=c_value,
                    class_weight=class_weight,
                    max_iter=3000,
                    solver="lbfgs",
                ),
            ),
        ]
    )


def fit_predict_pooled(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_pred: pd.DataFrame,
    features: list[str],
    c_value: float,
    class_weight,
    station_aware: bool,
) -> np.ndarray:
    cols = features + (["station_id"] if station_aware else [])
    model = make_model(features, c_value, class_weight, station_aware)
    model.fit(X_train[cols], y_train["Hot33"])
    return model.predict_proba(X_pred[cols])[:, 1]


def fit_station_models(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    features: list[str],
    c_value: float,
    class_weight,
) -> tuple[dict[str, Pipeline], pd.DataFrame]:
    models: dict[str, Pipeline] = {}
    status_rows = []
    for station, idx in X_train.groupby("station_id").groups.items():
        y = y_train.loc[idx, "Hot33"].astype(int)
        n_pos = int(y.sum())
        n_neg = int(len(y) - n_pos)
        status = {"station_id": station, "n_train": len(y), "positives": n_pos, "status": "ok"}
        if n_pos == 0 or n_neg == 0:
            status["status"] = "single_class"
            status_rows.append(status)
            continue
        model = make_model(features, c_value, class_weight, station_aware=False)
        try:
            model.fit(X_train.loc[idx, features], y)
            models[station] = model
        except Exception as exc:  # 极小样本下偶尔不收敛
            status["status"] = "fit_error"
            status["error"] = str(exc)
        status_rows.append(status)
    return models, pd.DataFrame(status_rows)


def predict_station_models(models: dict[str, Pipeline], X: pd.DataFrame, features: list[str]) -> np.ndarray:
    prob = pd.Series(np.nan, index=X.index, dtype=float)
    for station, idx in X.groupby("station_id").groups.items():
        if station in models:
            prob.loc[idx] = models[station].predict_proba(X.loc[idx, features])[:, 1]
    return prob.to_numpy()


def build_pred_frame(
    model_id: str,
    strategy_label: str,
    split: str,
    X: pd.DataFrame,
    y: pd.DataFrame,
    prob: np.ndarray,
    threshold: float,
) -> pd.DataFrame:
    df = pd.DataFrame(
        {
            "model": model_id,
            "strategy": strategy_label,
            "split": split,
            "station_id": X["station_id"].to_numpy(),
            "date": X["date"].to_numpy(),
            "y_true_hot33": y["Hot33"].to_numpy(),
            "p_hot33": prob,
        }
    )
    df["available"] = df["p_hot33"].notna()
    df["y_pred_hot33"] = np.where(df["available"], (df["p_hot33"] >= threshold).astype(float), np.nan)
    return df


def evaluate(pred: pd.DataFrame, thresholds: dict[str, float]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    overall_rows, station_rows, calib_rows = [], [], []
    # 三种策略都可用的公共站点集合（用于公平对比；station-specific 缺 TMS/VP1）
    common_stations: dict[str, set] = {}
    for split, gs in pred.groupby("split"):
        available_sets = [
            set(gm.loc[gm["available"], "station_id"].unique())
            for _, gm in gs.groupby("model")
        ]
        common_stations[split] = set.intersection(*available_sets) if available_sets else set()

    for (model, strategy, split), g in pred.groupby(["model", "strategy", "split"], sort=True):
        threshold = thresholds.get(model, 0.5)
        m = classification_metrics(g["y_true_hot33"], g["p_hot33"], threshold)
        m.update(
            {
                "model": model,
                "strategy": strategy,
                "split": split,
                "evaluation_set": "available",
                "n_stations": int(g.loc[g["available"], "station_id"].nunique()),
            }
        )
        overall_rows.append(m)

        g_common = g[g["station_id"].isin(common_stations[split])]
        mc = classification_metrics(g_common["y_true_hot33"], g_common["p_hot33"], threshold)
        mc.update(
            {
                "model": model,
                "strategy": strategy,
                "split": split,
                "evaluation_set": "common_stations",
                "n_stations": len(common_stations[split]),
            }
        )
        overall_rows.append(mc)

        for station, gs in g.groupby("station_id", sort=True):
            ms = classification_metrics(gs["y_true_hot33"], gs["p_hot33"], threshold)
            ms.update({"model": model, "strategy": strategy, "split": split, "station_id": station})
            station_rows.append(ms)

        cb = calibration_bins(g["y_true_hot33"], g["p_hot33"])
        cb.insert(0, "split", split)
        cb.insert(0, "strategy", strategy)
        cb.insert(0, "model", model)
        calib_rows.append(cb)

    overall = pd.DataFrame(overall_rows)
    by_station = pd.DataFrame(station_rows)
    calibration = pd.concat(calib_rows, ignore_index=True) if calib_rows else pd.DataFrame()
    return overall, by_station, calibration


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--c-grid", default="0.01,0.1,1,10")
    parser.add_argument("--variant", default="main", choices=["main", "complete_only"])
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()

    c_values = [float(c) for c in args.c_grid.split(",") if c.strip()]
    class_weights = [None, "balanced"]
    args.output_dir.mkdir(parents=True, exist_ok=True)

    manifest = load_manifest()
    features = manifest["numeric_features"]
    splits = {name: load_split(name, variant=args.variant) for name in ["train", "validation", "test"]}
    X_train, y_train = splits["train"]
    X_val, y_val = splits["validation"]

    print(f"数据包: {DATA_PKG} (variant={args.variant})")
    print(f"训练 {len(X_train)} | 验证 {len(X_val)} | 测试 {len(splits['test'][0])}")
    print(f"Hot33 训练正例: {int(y_train['Hot33'].sum())} ({y_train['Hot33'].mean():.2%})\n")

    selection: dict[str, dict] = {}
    thresholds: dict[str, float] = {}
    status_frames: list[pd.DataFrame] = []
    all_preds: list[pd.DataFrame] = []
    t_start = time.time()

    for model_id, cfg in STRATEGIES.items():
        label = cfg["label"]
        best = None
        for c_value in c_values:
            for weight in class_weights:
                if cfg["station_specific"]:
                    models, status = fit_station_models(X_train, y_train, features, c_value, weight)
                    val_prob = predict_station_models(models, X_val, features)
                else:
                    val_prob = fit_predict_pooled(
                        X_train, y_train, X_val, features, c_value, weight, cfg["station_aware"]
                    )
                m = classification_metrics(y_val["Hot33"], val_prob, 0.5)
                ap = m["pr_auc"]
                print(
                    f"{model_id} {label:<20} C={c_value:<5g} weight={str(weight):<8} "
                    f"验证 PR-AUC={ap:.4f}  n={m['n']}  正例={m['positives']}"
                )
                if best is None or (np.isfinite(ap) and ap > best["pr_auc"]):
                    best = {"c": c_value, "class_weight": weight, "pr_auc": ap, "n": m["n"], "positives": m["positives"]}
        selection[model_id] = {"label": label, **best}
        print(f"→ {model_id} 选择 C={best['c']:g}, class_weight={best['class_weight']}\n")

        # 用选中的超参重新拟合，选择阈值并输出三个划分的预测
        if cfg["station_specific"]:
            models, status = fit_station_models(X_train, y_train, features, best["c"], best["class_weight"])
            status.insert(0, "model", model_id)
            status_frames.append(status)
            val_prob = predict_station_models(models, X_val, features)
            threshold, val_f1 = best_f1_threshold(y_val["Hot33"], val_prob)
            thresholds[model_id] = threshold
            selection[model_id]["threshold"] = threshold
            selection[model_id]["validation_f1_at_threshold"] = val_f1
            for split_name, (X, y) in splits.items():
                prob = predict_station_models(models, X, features)
                all_preds.append(build_pred_frame(model_id, label, split_name, X, y, prob, threshold))
        else:
            cols = features + (["station_id"] if cfg["station_aware"] else [])
            model = make_model(features, best["c"], best["class_weight"], cfg["station_aware"])
            model.fit(X_train[cols], y_train["Hot33"])
            val_prob = model.predict_proba(X_val[cols])[:, 1]
            threshold, val_f1 = best_f1_threshold(y_val["Hot33"], val_prob)
            thresholds[model_id] = threshold
            selection[model_id]["threshold"] = threshold
            selection[model_id]["validation_f1_at_threshold"] = val_f1
            for split_name, (X, y) in splits.items():
                prob = model.predict_proba(X[cols])[:, 1]
                all_preds.append(build_pred_frame(model_id, label, split_name, X, y, prob, threshold))

        print(f"  阈值={thresholds[model_id]:.2f}  验证 F1={val_f1:.4f}\n")

    predictions = pd.concat(all_preds, ignore_index=True)
    overall, by_station, calibration = evaluate(predictions, thresholds)

    predictions.to_csv(args.output_dir / "classification_predictions.csv", index=False, encoding="utf-8-sig")
    overall.to_csv(args.output_dir / "classification_metrics_overall.csv", index=False, encoding="utf-8-sig")
    by_station.to_csv(args.output_dir / "classification_metrics_by_station.csv", index=False, encoding="utf-8-sig")
    calibration.to_csv(args.output_dir / "classification_calibration_bins.csv", index=False, encoding="utf-8-sig")
    if status_frames:
        pd.concat(status_frames, ignore_index=True).to_csv(
            args.output_dir / "classification_station_status.csv", index=False, encoding="utf-8-sig"
        )

    run_log = {
        "task": "Hot33 classification",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "data_package": str(DATA_PKG),
        "variant": args.variant,
        "n_features": len(features),
        "rows": {k: len(v[0]) for k, v in splits.items()},
        "c_grid": c_values,
        "class_weights": class_weights,
        "selection": selection,
        "sklearn_version": sklearn.__version__,
        "pandas_version": pd.__version__,
        "runtime_seconds": round(time.time() - t_start, 2),
    }
    (args.output_dir / "classification_run_log.json").write_text(
        json.dumps(run_log, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    show = overall[overall["split"].isin(["validation", "test"])]
    print("\n各策略总体指标（决策阈值已冻结）：")
    cols = ["model", "strategy", "split", "evaluation_set", "n", "n_stations", "positives", "pr_auc", "precision", "recall", "f1", "brier"]
    print(show[cols].to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print(f"\n结果已写入: {args.output_dir}")
    print(f"总耗时: {run_log['runtime_seconds']} 秒")


if __name__ == "__main__":
    main()
