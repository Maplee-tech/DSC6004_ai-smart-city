"""4号（模型训练与对比）— 公共工具：数据读取、预处理、回归指标。

数据来源：3号 data_38 数据包（main 版本）。
预处理逻辑与 3号 member3_pipeline/preprocessing.py 保持一致，
复制到本文件夹是为了让4号的代码独立可运行，不修改队友目录。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# ---------------------------------------------------------------- paths
HERE = Path(__file__).resolve()
PROJECT_ROOT = HERE.parents[3]          # D:\smart city课件\finalproject
MODELS_ROOT = HERE.parents[1]           # ...\6005finalproject\04_models
DATA_PKG = (
    PROJECT_ROOT
    / "DSC6004_数据特征处理"
    / "DSC6004_数据特征处理"
    / "member3_pipeline"
    / "data_38"
)
OUTPUT_DIR = MODELS_ROOT / "outputs"


def load_manifest(data_pkg: Path = DATA_PKG) -> dict:
    return json.loads((data_pkg / "manifest.json").read_text(encoding="utf-8"))


def load_split(split: str, data_pkg: Path = DATA_PKG, variant: str = "main"):
    """读取 X/y 并校验连接键一一对应。"""
    folder = data_pkg / variant
    x = pd.read_csv(folder / f"X_{split}.csv", dtype={"station_id": str})
    y = pd.read_csv(folder / f"y_{split}.csv", dtype={"station_id": str})
    x["date"] = pd.to_datetime(x["date"])
    y["date"] = pd.to_datetime(y["date"])
    pd.testing.assert_frame_equal(
        x[["date", "station_id"]].reset_index(drop=True),
        y[["date", "station_id"]].reset_index(drop=True),
    )
    return x, y


# ---------------------------------------------------------------- preprocessing
def make_preprocessor(numeric_features: list[str], station_aware: bool = True) -> ColumnTransformer:
    """训练集内拟合：中位数填补 + 缺失指示 + 标准化；可选 station_id 独热。

    station_aware=False 对应 city-global（看不到站点身份）。
    """
    numeric = Pipeline(
        [
            ("impute", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True)),
            ("scale", StandardScaler()),
        ]
    )
    transforms = [("numeric", numeric, numeric_features)]
    if station_aware:
        transforms.append(
            ("station", OneHotEncoder(handle_unknown="ignore", sparse_output=False), ["station_id"])
        )
    return ColumnTransformer(transforms, remainder="drop")


# ---------------------------------------------------------------- metrics
def regression_metrics(y_true, y_pred) -> dict:
    """MAE / RMSE / 平均有符号偏差 / 低估率。"""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true, y_pred = y_true[mask], y_pred[mask]
    if y_true.size == 0:
        return {"n": 0, "mae": np.nan, "rmse": np.nan, "bias": np.nan, "underprediction_rate": np.nan}
    err = y_pred - y_true
    return {
        "n": int(y_true.size),
        "mae": float(np.mean(np.abs(err))),
        "rmse": float(np.sqrt(np.mean(err**2))),
        "bias": float(np.mean(err)),
        "underprediction_rate": float(np.mean(err < 0)),
    }


def subset_masks(df: pd.DataFrame) -> dict[str, pd.Series]:
    """评估子集（基于观测到的真实标签，仅用于评估分层）。"""
    return {
        "all": pd.Series(True, index=df.index),
        "observed_Hot33": df["hot33"] == 1,
        "observed_Tmax_ge_35": df["y_true"] >= 35.0,
        "observed_ExtremeP95": df["extreme_p95"] == 1,
    }


def evaluate_predictions(pred: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """返回 (总体+子集指标表, 逐站指标表)。

    pred 需包含列：model, strategy, split, station_id, date, y_true, y_pred,
    hot33, hot34, extreme_p95。
    """
    overall_rows = []
    for (model, strategy, split), g in pred.groupby(["model", "strategy", "split"], sort=True):
        for subset, mask in subset_masks(g).items():
            m = regression_metrics(g.loc[mask, "y_true"], g.loc[mask, "y_pred"])
            overall_rows.append(
                {
                    "model": model,
                    "strategy": strategy,
                    "split": split,
                    "subset": subset,
                    **m,
                }
            )
    overall = pd.DataFrame(overall_rows)

    station_rows = []
    for (model, strategy, split, station), g in pred.groupby(
        ["model", "strategy", "split", "station_id"], sort=True
    ):
        m = regression_metrics(g["y_true"], g["y_pred"])
        station_rows.append(
            {
                "model": model,
                "strategy": strategy,
                "split": split,
                "station_id": station,
                **m,
            }
        )
    by_station = pd.DataFrame(station_rows)
    return overall, by_station


# ---------------------------------------------------------------- classification metrics
def classification_metrics(y_true, y_prob, threshold: float = 0.5) -> dict:
    """PR-AUC / ROC-AUC / 精确率 / 召回率 / F1 / Brier / log loss。

    只统计 y_true 与 y_prob 都有效的行；单类别子集的相关指标记为 NaN。
    """
    y = pd.Series(y_true, dtype="float64").to_numpy()
    p = pd.Series(y_prob, dtype="float64").to_numpy()
    mask = np.isfinite(y) & np.isfinite(p)
    y, p = y[mask], p[mask]
    n = int(y.size)
    positives = int(np.sum(y == 1)) if n else 0
    out = {
        "n": n,
        "positives": positives,
        "base_rate": positives / n if n else np.nan,
        "threshold": float(threshold),
    }
    if n == 0:
        out.update({k: np.nan for k in ["pr_auc", "roc_auc", "precision", "recall", "f1", "brier", "log_loss"]})
        return out

    if len(np.unique(y)) == 2:
        out["pr_auc"] = float(average_precision_score(y, p))
        out["roc_auc"] = float(roc_auc_score(y, p))
    else:
        out["pr_auc"] = np.nan
        out["roc_auc"] = np.nan

    y_hat = (p >= threshold).astype(int)
    tp = int(np.sum((y_hat == 1) & (y == 1)))
    fp = int(np.sum((y_hat == 1) & (y == 0)))
    fn = int(np.sum((y_hat == 0) & (y == 1)))
    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    out["precision"] = precision
    out["recall"] = recall
    if np.isfinite(precision) and np.isfinite(recall) and (precision + recall) > 0:
        out["f1"] = 2 * precision * recall / (precision + recall)
    else:
        out["f1"] = np.nan
    out["brier"] = float(np.mean((p - y) ** 2))
    try:
        out["log_loss"] = float(log_loss(y, p, labels=[0, 1]))
    except ValueError:
        out["log_loss"] = np.nan
    return out


def best_f1_threshold(y_true, y_prob, step: float = 0.01) -> tuple[float, float]:
    """在验证集上选使 F1 最大的概率阈值。"""
    y = pd.Series(y_true, dtype="float64").to_numpy()
    p = pd.Series(y_prob, dtype="float64").to_numpy()
    mask = np.isfinite(y) & np.isfinite(p)
    y, p = y[mask], p[mask]
    if y.size == 0 or np.sum(y == 1) == 0:
        return 0.5, np.nan
    best_t, best_f1 = 0.5, -1.0
    for t in np.arange(step, 1.0, step):
        y_hat = (p >= t).astype(int)
        tp = int(np.sum((y_hat == 1) & (y == 1)))
        fp = int(np.sum((y_hat == 1) & (y == 0)))
        fn = int(np.sum((y_hat == 0) & (y == 1)))
        if tp == 0:
            f1 = 0.0
        else:
            precision = tp / (tp + fp)
            recall = tp / (tp + fn)
            f1 = 2 * precision * recall / (precision + recall)
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    return best_t, float(best_f1)


def calibration_bins(y_true, y_prob, n_bins: int = 10) -> pd.DataFrame:
    """输出可靠性图/校准表所需的概率分箱统计。"""
    y = pd.Series(y_true, dtype="float64").to_numpy()
    p = pd.Series(y_prob, dtype="float64").to_numpy()
    mask = np.isfinite(y) & np.isfinite(p)
    y, p = y[mask], p[mask]
    if y.size == 0:
        return pd.DataFrame(columns=["bin_lower", "bin_upper", "n", "mean_pred", "observed_rate"])
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, n_bins - 1)
    rows = []
    for b in range(n_bins):
        m = idx == b
        if not m.any():
            continue
        rows.append(
            {
                "bin_lower": float(edges[b]),
                "bin_upper": float(edges[b + 1]),
                "n": int(m.sum()),
                "mean_pred": float(p[m].mean()),
                "observed_rate": float(y[m].mean()),
            }
        )
    return pd.DataFrame(rows)
