"""4号 回归任务（Tmax）：三种策略对比

M1 city-global          : 一个 Ridge，所有站混训，不带站点身份
M2 station-specific     : 每站一个 Ridge
M3 pooled station-aware : 一个 Ridge，station_id 作为类别特征

流程：2024 训练 → 2025 验证集选 alpha → 冻结后在 2025/2026 上评估。
2026 只用于最终评估，不参与任何选择。

运行：
    python train_regression.py
    python train_regression.py --alpha-grid 0.1,1,10,100
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline

from common import (
    DATA_PKG,
    OUTPUT_DIR,
    evaluate_predictions,
    load_manifest,
    load_split,
    make_preprocessor,
    regression_metrics,
)

STRATEGIES = {
    "M1": {"label": "city_global", "station_aware": False, "station_specific": False},
    "M2": {"label": "station_specific", "station_aware": False, "station_specific": True},
    "M3": {"label": "pooled_station_aware", "station_aware": True, "station_specific": False},
}


def make_model(features: list[str], alpha: float, station_aware: bool) -> Pipeline:
    return Pipeline(
        [
            ("preprocess", make_preprocessor(features, station_aware=station_aware)),
            ("model", Ridge(alpha=alpha)),
        ]
    )


def fit_predict_pooled(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_pred: pd.DataFrame,
    features: list[str],
    alpha: float,
    station_aware: bool,
) -> np.ndarray:
    cols = features + (["station_id"] if station_aware else [])
    model = make_model(features, alpha, station_aware)
    model.fit(X_train[cols], y_train["tmax_target"])
    return model.predict(X_pred[cols])


def fit_station_models(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    features: list[str],
    alpha: float,
) -> dict[str, Pipeline]:
    models: dict[str, Pipeline] = {}
    for station, idx in X_train.groupby("station_id").groups.items():
        model = make_model(features, alpha, station_aware=False)
        model.fit(X_train.loc[idx, features], y_train.loc[idx, "tmax_target"])
        models[station] = model
    return models


def predict_station_models(models: dict[str, Pipeline], X: pd.DataFrame, features: list[str]) -> np.ndarray:
    pred = pd.Series(index=X.index, dtype=float)
    for station, idx in X.groupby("station_id").groups.items():
        if station not in models:
            raise KeyError(f"没有站点 {station} 的模型，无法预测")
        pred.loc[idx] = models[station].predict(X.loc[idx, features])
    if pred.isna().any():
        raise RuntimeError("存在未覆盖的预测行")
    return pred.to_numpy()


def build_pred_frame(
    model_id: str,
    strategy_label: str,
    split: str,
    X: pd.DataFrame,
    y: pd.DataFrame,
    y_pred: np.ndarray,
) -> pd.DataFrame:
    df = pd.DataFrame(
        {
            "model": model_id,
            "strategy": strategy_label,
            "split": split,
            "station_id": X["station_id"].to_numpy(),
            "date": X["date"].to_numpy(),
            "y_true": y["tmax_target"].to_numpy(),
            "y_pred": y_pred,
            "hot33": y["Hot33"].to_numpy(),
            "hot34": y["Hot34"].to_numpy(),
            "extreme_p95": y["ExtremeP95"].to_numpy(),
        }
    )
    df["residual"] = df["y_pred"] - df["y_true"]
    df["abs_error"] = df["residual"].abs()
    return df


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha-grid", default="0.1,1,10,100")
    parser.add_argument("--variant", default="main", choices=["main", "complete_only"])
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()

    alphas = [float(a) for a in args.alpha_grid.split(",") if a.strip()]
    args.output_dir.mkdir(parents=True, exist_ok=True)

    manifest = load_manifest()
    features = manifest["numeric_features"]
    splits = {name: load_split(name, variant=args.variant) for name in ["train", "validation", "test"]}
    X_train, y_train = splits["train"]
    X_val, y_val = splits["validation"]
    X_test, y_test = splits["test"]

    print(f"数据包: {DATA_PKG} (variant={args.variant})")
    print(f"特征数: {len(features)} | 训练 {len(X_train)} | 验证 {len(X_val)} | 测试 {len(X_test)}")
    print(f"alpha 候选: {alphas}\n")

    all_preds: list[pd.DataFrame] = []
    selection: dict[str, dict] = {}
    t_start = time.time()

    for model_id, cfg in STRATEGIES.items():
        label = cfg["label"]
        alpha_scores: dict[float, dict] = {}

        for alpha in alphas:
            if cfg["station_specific"]:
                models = fit_station_models(X_train, y_train, features, alpha)
                val_pred = predict_station_models(models, X_val, features)
            else:
                val_pred = fit_predict_pooled(
                    X_train, y_train, X_val, features, alpha, cfg["station_aware"]
                )
            m = regression_metrics(y_val["tmax_target"], val_pred)
            alpha_scores[alpha] = m
            print(f"{model_id} {label:<20} alpha={alpha:<6g} 验证 MAE={m['mae']:.4f}  RMSE={m['rmse']:.4f}")

        best_alpha = min(alpha_scores, key=lambda a: alpha_scores[a]["mae"])
        selection[model_id] = {
            "label": label,
            "best_alpha": best_alpha,
            "alpha_scores": {str(a): alpha_scores[a] for a in alphas},
        }
        print(f"→ {model_id} 选择 alpha={best_alpha:g}\n")

        # 用选定的 alpha 重新拟合，再对 train/validation/test 统一预测
        if cfg["station_specific"]:
            models = fit_station_models(X_train, y_train, features, best_alpha)
            for split_name, (X, y) in splits.items():
                pred = predict_station_models(models, X, features)
                all_preds.append(build_pred_frame(model_id, label, split_name, X, y, pred))
        else:
            cols = features + (["station_id"] if cfg["station_aware"] else [])
            model = make_model(features, best_alpha, cfg["station_aware"])
            model.fit(X_train[cols], y_train["tmax_target"])
            for split_name, (X, y) in splits.items():
                pred = model.predict(X[cols])
                all_preds.append(build_pred_frame(model_id, label, split_name, X, y, pred))

    predictions = pd.concat(all_preds, ignore_index=True)
    overall, by_station = evaluate_predictions(predictions)

    predictions.to_csv(args.output_dir / "predictions.csv", index=False, encoding="utf-8-sig")
    overall.to_csv(args.output_dir / "metrics_overall.csv", index=False, encoding="utf-8-sig")
    by_station.to_csv(args.output_dir / "metrics_by_station.csv", index=False, encoding="utf-8-sig")

    run_log = {
        "task": "Tmax regression",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "data_package": str(DATA_PKG),
        "variant": args.variant,
        "n_features": len(features),
        "features": features,
        "rows": {k: len(v[0]) for k, v in splits.items()},
        "alpha_grid": alphas,
        "selection": selection,
        "sklearn_version": sklearn.__version__,
        "pandas_version": pd.__version__,
        "runtime_seconds": round(time.time() - t_start, 2),
    }
    (args.output_dir / "run_log.json").write_text(
        json.dumps(run_log, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    show = overall[(overall["subset"] == "all") & (overall["split"].isin(["validation", "test"]))]
    print("\n各策略总体指标（all）：")
    print(show[["model", "strategy", "split", "n", "mae", "rmse", "bias", "underprediction_rate"]]
          .to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print(f"\n结果已写入: {args.output_dir}")
    print(f"总耗时: {run_log['runtime_seconds']} 秒")


if __name__ == "__main__":
    main()
