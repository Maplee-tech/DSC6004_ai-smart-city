"""LOSO 留一站验证（pooled station-aware 策略）

每一折完全排除一个站点：
- 训练：2024 年其余 37 个站
- 选参/选阈值：2025 年其余 37 个站
- 评估：被留出站点自己的 2025（验证）与 2026（测试）行
- 被留出站点的历史温度仍可作为输入（属于“有历史的新站迁移”，不是零历史冷启动）
- station-specific 策略无法对未见站点建模，按 NA 处理

运行：
    python loso.py
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.pipeline import Pipeline

from common import (
    DATA_PKG,
    OUTPUT_DIR,
    best_f1_threshold,
    classification_metrics,
    load_manifest,
    load_split,
    make_preprocessor,
    regression_metrics,
)

ALPHAS = [0.1, 1.0, 10.0, 100.0]
C_VALUES = [0.01, 0.1, 1.0, 10.0]
CLASS_WEIGHTS = [None, "balanced"]


def fit_select_regression(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_val: pd.DataFrame,
    y_val: pd.DataFrame,
    features: list[str],
) -> tuple[Pipeline, float, dict]:
    cols = features + ["station_id"]
    best = None
    scores = {}
    for alpha in ALPHAS:
        model = Pipeline(
            [
                ("preprocess", make_preprocessor(features, station_aware=True)),
                ("model", Ridge(alpha=alpha)),
            ]
        )
        model.fit(X_train[cols], y_train["tmax_target"])
        pred = model.predict(X_val[cols])
        mae = regression_metrics(y_val["tmax_target"], pred)["mae"]
        scores[alpha] = mae
        if best is None or mae < best[1]:
            best = (model, mae, alpha)
    model, _, alpha = best
    return model, alpha, scores


def fit_select_classification(
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_val: pd.DataFrame,
    y_val: pd.DataFrame,
    features: list[str],
) -> tuple[Pipeline, float, object, float, dict]:
    cols = features + ["station_id"]
    best = None
    scores = {}
    for c_value in C_VALUES:
        for weight in CLASS_WEIGHTS:
            model = Pipeline(
                [
                    ("preprocess", make_preprocessor(features, station_aware=True)),
                    (
                        "model",
                        LogisticRegression(
                            C=c_value, class_weight=weight, max_iter=3000, solver="lbfgs"
                        ),
                    ),
                ]
            )
            model.fit(X_train[cols], y_train["Hot33"])
            prob = model.predict_proba(X_val[cols])[:, 1]
            ap = classification_metrics(y_val["Hot33"], prob, 0.5)["pr_auc"]
            scores[(c_value, str(weight))] = ap
            if best is None or (np.isfinite(ap) and ap > best[1]):
                best = (model, ap, c_value, weight, prob)
    model, _, c_value, weight, val_prob = best
    threshold, val_f1 = best_f1_threshold(y_val["Hot33"], val_prob)
    return model, c_value, weight, threshold, {"pr_auc": scores, "val_f1": val_f1}


def pooled_classification_metrics(y_true, prob, y_hat) -> dict:
    """合并所有折的留出站预测后的指标（阈值已在各折内独立选择）。"""
    y = pd.Series(y_true, dtype="float64").to_numpy()
    p = pd.Series(prob, dtype="float64").to_numpy()
    h = pd.Series(y_hat, dtype="float64").to_numpy()
    mask = np.isfinite(y) & np.isfinite(p) & np.isfinite(h)
    y, p, h = y[mask], p[mask], h[mask]
    n = int(y.size)
    positives = int((y == 1).sum())
    out = {"n": n, "positives": positives, "base_rate": positives / n if n else np.nan, "threshold": np.nan}
    if len(np.unique(y)) == 2:
        out["pr_auc"] = float(average_precision_score(y, p))
        out["roc_auc"] = float(roc_auc_score(y, p))
    else:
        out["pr_auc"] = np.nan
        out["roc_auc"] = np.nan
    tp = int(((h == 1) & (y == 1)).sum())
    fp = int(((h == 1) & (y == 0)).sum())
    fn = int(((h == 0) & (y == 1)).sum())
    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    out["precision"] = precision
    out["recall"] = recall
    out["f1"] = (
        2 * precision * recall / (precision + recall)
        if np.isfinite(precision) and np.isfinite(recall) and (precision + recall) > 0
        else np.nan
    )
    out["brier"] = float(np.mean((p - y) ** 2))
    try:
        out["log_loss"] = float(log_loss(y, p, labels=[0, 1]))
    except ValueError:
        out["log_loss"] = np.nan
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", default="main", choices=["main", "complete_only"])
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest()
    features = manifest["numeric_features"]
    splits = {name: load_split(name, variant=args.variant) for name in ["train", "validation", "test"]}
    X_train, y_train = splits["train"]
    X_val, y_val = splits["validation"]
    X_test, y_test = splits["test"]
    stations = sorted(X_train["station_id"].unique())

    # 全量 M3（训练时包含所有站）作为“seen station”参照
    reg_full = pd.read_csv(args.output_dir / "predictions.csv")
    reg_full = reg_full[(reg_full["model"] == "M3") & (reg_full["split"].isin(["validation", "test"]))]
    clf_full = pd.read_csv(args.output_dir / "classification_predictions.csv")
    clf_full = clf_full[(clf_full["model"] == "M3") & (clf_full["split"].isin(["validation", "test"]))]
    clf_run = json.loads((args.output_dir / "classification_run_log.json").read_text(encoding="utf-8"))
    m3_threshold = clf_run["selection"]["M3"]["threshold"]

    reg_fold_rows, clf_fold_rows = [], []
    reg_pred_rows, clf_pred_rows = [], []
    t0 = time.time()

    for i, station in enumerate(stations, start=1):
        # 训练集：排除被留出站
        tr_mask = X_train["station_id"] != station
        val_train_mask = X_val["station_id"] != station
        val_hold_mask = X_val["station_id"] == station
        test_hold_mask = X_test["station_id"] == station

        Xt, yt = X_train.loc[tr_mask], y_train.loc[tr_mask]
        Xv, yv = X_val.loc[val_train_mask], y_val.loc[val_train_mask]

        # ---------------- regression
        model, alpha, scores = fit_select_regression(Xt, yt, Xv, yv, features)
        cols = features + ["station_id"]
        for split_name, X_hold, y_hold in [
            ("validation", X_val.loc[val_hold_mask], y_val.loc[val_hold_mask]),
            ("test", X_test.loc[test_hold_mask], y_test.loc[test_hold_mask]),
        ]:
            pred = model.predict(X_hold[cols])
            m = regression_metrics(y_hold["tmax_target"], pred)
            m3 = reg_full[
                (reg_full["split"] == split_name) & (reg_full["station_id"] == station)
            ]
            m3_metrics = regression_metrics(m3["y_true"], m3["y_pred"])
            reg_fold_rows.append(
                {
                    "held_out_station": station,
                    "split": split_name,
                    "alpha": alpha,
                    **m,
                    "m3_insample_mae": m3_metrics["mae"],
                    "delta_mae_loso_minus_insample": m["mae"] - m3_metrics["mae"],
                }
            )
            reg_pred_rows.append(
                pd.DataFrame(
                    {
                        "task": "regression",
                        "held_out_station": station,
                        "split": split_name,
                        "station_id": X_hold["station_id"].to_numpy(),
                        "date": X_hold["date"].to_numpy(),
                        "y_true": y_hold["tmax_target"].to_numpy(),
                        "y_pred": pred,
                    }
                )
            )

        # ---------------- classification
        model_c, c_value, weight, threshold, extra = fit_select_classification(Xt, yt, Xv, yv, features)
        for split_name, X_hold, y_hold in [
            ("validation", X_val.loc[val_hold_mask], y_val.loc[val_hold_mask]),
            ("test", X_test.loc[test_hold_mask], y_test.loc[test_hold_mask]),
        ]:
            prob = model_c.predict_proba(X_hold[cols])[:, 1]
            m = classification_metrics(y_hold["Hot33"], prob, threshold)
            m3 = clf_full[
                (clf_full["split"] == split_name) & (clf_full["station_id"] == station)
            ]
            m3_metrics = classification_metrics(m3["y_true_hot33"], m3["p_hot33"], m3_threshold)
            clf_fold_rows.append(
                {
                    "held_out_station": station,
                    "split": split_name,
                    "C": c_value,
                    "class_weight": str(weight),
                    "threshold": threshold,
                    **m,
                    "m3_insample_pr_auc": m3_metrics["pr_auc"],
                    "m3_insample_f1": m3_metrics["f1"],
                    "delta_pr_auc_loso_minus_insample": m["pr_auc"] - m3_metrics["pr_auc"],
                }
            )
            clf_pred_rows.append(
                pd.DataFrame(
                    {
                        "task": "classification",
                        "held_out_station": station,
                        "split": split_name,
                        "station_id": X_hold["station_id"].to_numpy(),
                        "date": X_hold["date"].to_numpy(),
                        "y_true_hot33": y_hold["Hot33"].to_numpy(),
                        "p_hot33": prob,
                        "threshold": threshold,
                        "y_pred_hot33": (prob >= threshold).astype(float),
                    }
                )
            )

        if i % 5 == 0 or i == len(stations):
            print(f"[{i}/{len(stations)}] 已完成留出站点 {station}")

    reg_fold = pd.DataFrame(reg_fold_rows)
    clf_fold = pd.DataFrame(clf_fold_rows)
    reg_pred = pd.concat(reg_pred_rows, ignore_index=True)
    clf_pred = pd.concat(clf_pred_rows, ignore_index=True)

    # ---------------- pooled summary (all held-out stations together)
    summary_rows = []
    for split_name in ["validation", "test"]:
        r = reg_pred[reg_pred["split"] == split_name]
        m_loso = regression_metrics(r["y_true"], r["y_pred"])
        m_m3 = regression_metrics(
            reg_full.loc[reg_full["split"] == split_name, "y_true"],
            reg_full.loc[reg_full["split"] == split_name, "y_pred"],
        )
        summary_rows.append({"task": "regression", "split": split_name, "model": "LOSO", **m_loso})
        summary_rows.append({"task": "regression", "split": split_name, "model": "M3_insample", **m_m3})

        c = clf_pred[clf_pred["split"] == split_name]
        c_m3 = clf_full[clf_full["split"] == split_name]
        summary_rows.append(
            {
                "task": "classification",
                "split": split_name,
                "model": "LOSO",
                **pooled_classification_metrics(c["y_true_hot33"], c["p_hot33"], c["y_pred_hot33"]),
            }
        )
        summary_rows.append(
            {
                "task": "classification",
                "split": split_name,
                "model": "M3_insample",
                **pooled_classification_metrics(
                    c_m3["y_true_hot33"],
                    c_m3["p_hot33"],
                    (c_m3["p_hot33"] >= m3_threshold).astype(float),
                ),
            }
        )
    summary = pd.DataFrame(summary_rows)

    # 逐站数值的宏观平均（只统计指标有定义的折）
    macro = (
        reg_fold.groupby("split")
        .agg(
            mae_mean=("mae", "mean"),
            mae_median=("mae", "median"),
            mae_min=("mae", "min"),
            mae_max=("mae", "max"),
            stations=("held_out_station", "nunique"),
        )
        .reset_index()
    )

    reg_fold.to_csv(args.output_dir / "loso_regression_by_fold.csv", index=False, encoding="utf-8-sig")
    clf_fold.to_csv(args.output_dir / "loso_classification_by_fold.csv", index=False, encoding="utf-8-sig")
    reg_pred.to_csv(args.output_dir / "loso_regression_predictions.csv", index=False, encoding="utf-8-sig")
    clf_pred.to_csv(args.output_dir / "loso_classification_predictions.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(args.output_dir / "loso_pooled_summary.csv", index=False, encoding="utf-8-sig")
    macro.to_csv(args.output_dir / "loso_regression_macro.csv", index=False, encoding="utf-8-sig")

    run_log = {
        "task": "LOSO leave-one-station-out",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "data_package": str(DATA_PKG),
        "variant": args.variant,
        "folds": len(stations),
        "protocol": {
            "train": "2024, all stations except held-out",
            "selection": "2025, all stations except held-out",
            "evaluation": "held-out station 2025 and 2026",
            "held_out_history_allowed": True,
            "station_specific": "NA (cannot predict unseen station)",
        },
        "regression_alpha_grid": ALPHAS,
        "classification_c_grid": C_VALUES,
        "classification_class_weights": [str(w) for w in CLASS_WEIGHTS],
        "m3_threshold": m3_threshold,
        "sklearn_version": sklearn.__version__,
        "runtime_seconds": round(time.time() - t0, 2),
    }
    (args.output_dir / "loso_run_log.json").write_text(
        json.dumps(run_log, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("\nLOSO 汇总（所有留出站合并）：")
    cols = ["task", "split", "model", "n", "positives", "mae", "rmse", "pr_auc", "precision", "recall", "f1", "brier"]
    cols = [c for c in cols if c in summary.columns]
    print(summary[cols].to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print(f"\n结果已写入: {args.output_dir}")
    print(f"总耗时: {run_log['runtime_seconds']} 秒")


if __name__ == "__main__":
    main()
