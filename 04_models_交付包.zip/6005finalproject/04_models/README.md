# 04_models — 4号模型交付说明

本文件合并了原 `README.md` 与 `建模计划_v1.md`，是 04_models 的唯一说明文档。负责人：郑智明（4号）。

## 1. 目录结构

```
04_models/
├── README.md                                  ← 本文件
├── requirements.txt                           ← 运行依赖（numpy / pandas / scikit-learn）
├── scripts/
│   ├── common.py                              ← 数据路径、读取 X/y、预处理、回归/分类指标
│   ├── train_regression.py                    ← 任务一：Tmax 回归，三种策略（M1/M2/M3）
│   ├── train_classification.py                ← 任务二：Hot33 分类，三种策略（M1/M2/M3）
│   └── loso.py                                ← LOSO 留一站验证（pooled station-aware）
└── outputs/
    ├── predictions.csv                        ← 回归预测明细（全部模型 × 划分 × 站点日）
    ├── metrics_overall.csv                    ← 回归总体指标 + 极端子集指标
    ├── metrics_by_station.csv                 ← 回归逐站指标
    ├── run_log.json                           ← 回归选参记录、数据版本、运行信息
    ├── classification_predictions.csv         ← 分类预测明细（含概率、阈值、是否可用）
    ├── classification_metrics_overall.csv     ← 分类总体指标（含 36 站公共子集）
    ├── classification_metrics_by_station.csv  ← 分类逐站指标
    ├── classification_calibration_bins.csv    ← 分类概率校准分箱（可靠性图数据）
    ├── classification_station_status.csv      ← 分站模型拟合状态（单类别站记 NA）
    ├── classification_run_log.json            ← 分类选参记录、阈值、运行信息
    ├── loso_regression_predictions.csv        ← LOSO 留出站的回归预测明细
    ├── loso_regression_by_fold.csv            ← LOSO 逐折回归指标 + 全量 M3 对照
    ├── loso_regression_macro.csv              ← LOSO 回归逐站指标的汇总统计
    ├── loso_classification_predictions.csv    ← LOSO 留出站的分类预测明细
    ├── loso_classification_by_fold.csv        ← LOSO 逐折分类指标 + 全量 M3 对照
    ├── loso_pooled_summary.csv               ← LOSO 与全量 M3 的合并对比
    └── loso_run_log.json                      ← LOSO 协议与运行信息
```

运行顺序（在 `scripts/` 下）：

```powershell
python train_regression.py
python train_classification.py
python loso.py
```

## 2. 做了什么与结果

用3号的 `data_38/main` 数据包，按 proposal 的框架完成 **两种任务 × 三种策略**；2024 训练、2025 验证选参/选阈值、2026 只做最终评估。

### 任务一：Tmax 回归

| 编号 | 策略 | 模型 | 验证 MAE | 验证 RMSE | 测试 MAE | 测试 RMSE |
|---|---|---|---:|---:|---:|---:|
| M1 | city-global | Ridge（不带站点身份） | 1.791 | 2.340 | 1.740 | 2.236 |
| M2 | station-specific | Ridge ×38（每站一个） | 1.790 | 2.326 | 1.728 | 2.214 |
| **M3** | **pooled station-aware** | **Ridge + station_id 独热** | **1.774** | **2.316** | **1.723** | **2.217** |

极端子集（测试集）：三个模型在观测 Hot33 日的平均偏差约 −1.3°C、观测 ≥35°C 日约 −1.7°C，低估率 87%–93%——模型整体 MAE 约 1.7°C，但越热的天气越容易报低，这是报告要重点讨论的局限。

### 任务二：Hot33 分类

M1/M3 覆盖 38 站；M2 只有 36 站（大帽山 TMS、山顶 VP1 训练期无 Hot33 正例，无法拟合，记 NA）。为公平，下表为 36 站公共子集。

| 编号 | 策略 | 模型 | 验证 PR-AUC | 测试 PR-AUC | 测试 F1 | 测试 Brier |
|---|---|---|---:|---:|---:|---:|
| M1 | city-global | 逻辑回归（不带站点身份） | 0.640 | 0.668 | **0.648** | 0.069 |
| M2 | station-specific | 逻辑回归 ×36 | 0.608 | 0.644 | 0.617 | 0.072 |
| **M3** | **pooled station-aware** | **逻辑回归 + station_id 独热** | **0.649** | **0.676** | 0.644 | **0.068** |

决策阈值在 2025 验证集按 F1 最大化选定（M1=0.31、M2=0.29、M3=0.30），冻结后用于 2026。M3 的 PR-AUC 和 Brier 均为最优；M1 的测试 F1 略高（0.648 vs 0.644），属于阈值带来的精确率/召回率权衡。高分概率存在高估（例如预测 0.9–1.0 的样本实际发生率约 0.79），报告应附校准曲线。

**结论**：两个任务综合最优都是 **M3 pooled station-aware**——它共享全部站点的样本，同时用 station_id 保留站点差异；M2 每站样本少、部分站正例极少，表现最弱。

## 3. 数据集说明（对接用）

两个任务共用同一份数据，来自3号：

```
../member3_pipeline/data_38/main/
├── X_train.csv / X_validation.csv / X_test.csv
└── y_train.csv / y_validation.csv / y_test.csv
```

**X（特征表）**：`date`、`station_id` + 25 个数值特征。

- 滞后：`tmax_lag_1/2/3/7/14`（5个）
- 滚动 3/7/14 天：`tmax_roll_{w}_mean/std/min/max/count`（15个）
- 日历：`month`、`day_of_week`、`day_of_year`、`doy_sin`、`doy_cos`（5个）

**y（标签表）**：`date`、`station_id`、`tmax_target`（任务一目标）、`Hot32`、`Hot33`（任务二目标）、`Hot34`、`ExtremeP95`（敏感性/补充标签）。

**划分与规模**：

| 划分 | 年份 | 行数 | 说明 |
|---|---|---:|---|
| train | 2024 | 13,784 | 38站 |
| validation | 2025 | 13,784 | 38站，用于选 alpha / C / 阈值 |
| test | 2026 | 10,263 | 2026-01-01 至 2026-09-30；HKA 机场站只到 2026-08-31 |

- 连接键：`(date, station_id)`，X 与 y 行序一一对应（脚本内有断言）。
- 缺失目标已由3号剔除出监督样本；主版本 `main` 使用含 `#` 不完整观测的 `tmax_analysis_c`；`complete_only` 为敏感性版本，未在本轮使用。
- 日期只作连接键，不进入模型；所有特征只使用预测日 D 之前的观测（D−1 一步预测）。
- 交付预测明细：回归 `predictions.csv`（`model, strategy, split, station_id, date, y_true, y_pred, hot33, hot34, extreme_p95`）；分类 `classification_predictions.csv`（`model, strategy, split, station_id, date, y_true_hot33, p_hot33, available, y_pred_hot33`）。

## 4. LOSO 留一站验证

**验证过程**：对 pooled station-aware 策略做 38 折，每折完全留出一个站点。

1. 用其余 37 个站的 2024 年数据训练，预处理（填补、标准化、station_id 独热）只在训练折内拟合；
2. 用其余 37 个站的 2025 年数据选 alpha（回归）/ C 与 class_weight（分类），并在同一批数据上选 F1 最大化阈值；
3. 用选定的模型预测被留出站自己的 2025 和 2026 行；被留出站的历史温度仍作为输入（属于“有历史数据的新站迁移”，不是零历史冷启动）；
4. 被留出站的 station_id 在独热编码中为未见类别（全零），模型只能依靠温度历史和日历特征；
5. station-specific 策略无法对未见站点建模，按 NA 处理；2026 仍只用于最终评估。

**结果（所有留出站合并）**：

| 任务 | 指标 | 验证 LOSO | 验证 M3（含该站训练） | 测试 LOSO | 测试 M3（含该站训练） |
|---|---|---:|---:|---:|---:|
| 回归 | MAE | 1.802 | 1.774 | 1.755 | 1.723 |
| 回归 | RMSE | 2.342 | 2.316 | 2.245 | 2.217 |
| 分类 | PR-AUC | 0.619 | 0.649 | 0.655 | 0.676 |
| 分类 | F1 | 0.612 | 0.643 | 0.627 | 0.644 |
| 分类 | Brier | 0.069 | 0.066 | 0.067 | 0.064 |

- 回归：38 折测试 MAE 均值 1.756（范围 1.432–2.304），平均只比全量 M3 差约 0.03°C；31/38 个站略差。迁移损失最大的是大帽山 TMS（+0.31°C）和昂坪 NGP（+0.12°C）——高海拔/特殊站点的站点截距无法从其他站学到，符合预期。
- 分类：测试 PR-AUC 比全量 M3 低约 0.02、F1 低约 0.02；38 个留出站中有 35 个可以计算 PR-AUC（TMS、VP1、NGP 三站在评估期没有 Hot33 正例，AP 记为 NA）。整体迁移损失不大，pooled 策略对新站仍有可用的预测能力。
- 选参稳定：38 折中 34 折选择 alpha=100，37 折选择 C=1，说明前面的超参选择不是偶然。

**结论**：LOSO 验证了 pooled station-aware 策略对“有历史观测的新站”具有合理迁移能力，但会损失少量精度，尤其是与网络其他站差异大的站点。报告应把它写成“history-available transfer”，不能称为完全无历史的冷启动预测。
